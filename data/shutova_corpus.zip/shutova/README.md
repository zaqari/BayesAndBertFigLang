# Metaphor Corpus, 1.0 (2015-04-03)

See information at http://purl.org/net/metaphor-corpus

Please insert the following statement in any product, report, publication,
presentation and/or document that includes or references the data:
> This effort contains or makes use of the the IARPA-funded Metaphor Program
> USC/ISI annotated metaphorical language collection, release
> iarpa_metaphor_isi.edu_metaphor_corpus_20150403.


## Acknowledgements

This work was supported by the Intelligence Advanced Research Projects
Activity (IARPA) via Department of Defense US Army Research Laboratory
contract number W911NF-12-C-0025. The U.S. Government is authorized to
reproduce and distribute reprints for Governmental purposes
notwithstanding any copyright annotation thereon. Disclaimer: The views
and conclusions contained herein are those of the authors and should not
be interpreted as necessarily representing the official policies or
endorsements, either expressed or implied, of IARPA, DoD/ARL, or the
U.S. Government.
